## Angular TypeScript Snippets Changelog

<a name="2.0.0"></a>
# 2.0.0 (2017-01-23)

* Change prefix from `ng2-` to `a-` now that its just "Angular"
* Add `json` pipe snippets
